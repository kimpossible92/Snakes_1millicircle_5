﻿using System.Collections;
using UnityEngine;

public class EnemySp : MonoBehaviour
{
    public Gameplay.Spawners.Spawner GetSpawner;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}